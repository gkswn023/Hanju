package project11_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class GenericManager<T extends Comparable>{
	private ArrayList<T> cList;

	public GenericManager() {
		cList= new ArrayList<T>();
	}
	
	public void add(T a) {
		cList.add(a);
	}
	
	public void sort() {
		Collections.sort(cList);
	}
	
	public String find(T a) {
		String toReturn ="";
		for(Iterator<T> myIterator = cList.iterator();myIterator.hasNext();) {
			T listContact = myIterator.next();
			if(listContact.equals(a)) {
				toReturn+=listContact;
			}
		}
		return toReturn;
	}
	
	public String toString() {
		String toReturn ="";
		for(Iterator<T>myIterator = cList.iterator();myIterator.hasNext();) {
			T listContact =myIterator.next();
			toReturn+=listContact;
		}
		return toReturn;
	}
}
