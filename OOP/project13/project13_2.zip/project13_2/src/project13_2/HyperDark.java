package project13_2;

public class HyperDark extends Beverage {
	public HyperDark() {
		description = "Hyper dark roast"; 
		}	
	public double cost() { return 2.00; }
}
