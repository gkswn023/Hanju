package project13_2;

public abstract class Beverage {
	
	String description = "untitled";
	
	public String getDescription() {
		return description;
	}
	
	public abstract double cost();

}
