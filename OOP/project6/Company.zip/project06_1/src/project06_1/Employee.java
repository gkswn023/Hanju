package project06_1;

public class Employee {
	String name;
	int employeeNum;
	String department;
	
	public Employee(String name, int employeeNum) {
		this.name=name;
		this.employeeNum=employeeNum;
		this.department="No Dept";
	}
	
	public String getDepartment() { 
		return this.department;
	}
	public void setDepartment(String dept) { 
		this.department=dept;
	}
	
	public boolean equals(Employee compare) {
		if(compare.name.equals(name)&&compare.employeeNum==employeeNum)
			return true;
		else
			return false;
	}
	
	public String toString() { 
		return "Name : "+ name + "\n" + "Emp# : " + employeeNum;
	}
}
