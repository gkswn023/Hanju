package project06_1;

public class Manager extends Employee {
	int officeNum;
	String team;
	
	public Manager(String name, int employeeNum, int officeNum, String team) {
		super(name, employeeNum);
		this.officeNum=officeNum;
		this.team=team;
		}
	
	public boolean equals(Object obj) {
		if(obj==null)return false;
		else if(getClass() != obj.getClass()) return false;
		else {
			Manager otheremp = (Manager)obj;
			if(super.equals(otheremp)&&otheremp.officeNum==officeNum&&otheremp.team.equals(team))
				return true;
			else
				return false;
		}
		}
	
	public String toString() {
		return "Name : " + name + "\n" + "location :" + department +"," + officeNum;
	}
}