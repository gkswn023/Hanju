
public class Course {
	
	private String name;
	private String instructor;
	private String room;
	
	public Course() {
		this.name=null;
		this.instructor=null;
		this.room=null;
	}
	
	public Course(String name) {
		this.name=name;
		this.instructor=null;
		this.room=null;
	}
	
	public Course(String name, String instructor) {
		this.name=name;
		this.instructor=instructor;
		this.room=null;
	}
	
	public Course(String name, String instructor, String room) {
		this.name=name;
		this.instructor=instructor;
		this.room=room;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String getInstructor() {
		return this.instructor;
	}
	
	public void setInstructor(String instructor) {
		this.instructor=instructor;
	}
	
	public String getRoom() {
		return this.room;
	}
	
	public void setRoom(String room) {
		this.room=room;
	}
	
	public boolean equals(Course tmp) {
		if(tmp.name.equals(name)&&tmp.instructor.equals(instructor)&&tmp.room.equals(room))
			return true;
		else return false;
	}
	
	public String toString() {
		return "["+this.name+"] (["+this.instructor+"]) - #["+this.room+"]";
	}
	
	public static boolean isDuplicatedCourse(Course tmp,Course list) {
		if(tmp.equals(list)){
			return false;
		}
		else return true;
	}
}
