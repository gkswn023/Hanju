public class TimeTable {
	
	private String day;
	
	Course times[]=new Course[10];
	
	public TimeTable() { 
	this.day=null;
	for(int i=0;i<10;i++) {
			times[i]=new Course();
		}
	}
	public String getDay() {
		return this.day;
	}
	
	public void setDay(String day) {
		this.day=day;
	}
	
	public int setTimes(int i,Course course) {
		if(times[i]==null) {
			times[i]=course;
			return 1;
		}
		else if(times[i].equals(course)) {
			return 0;	
		}
		else{
			times[i]=course;
			return -1;
		}
	}
	
	public Course getTimes(int i) {
		return times[i];
	}
	
	public Course[] getAllTimes(){
		return times;
	}
	
	public boolean isEmptyTime(int i) {
		if(times[i].getName()==null) return true;
		else return false;
	}
}