package project10_1;

import java.util.Arrays;

public class MyCustom implements MyInterface {
	private Integer move_type = 0;
	private Boolean isAttack = false;
	
	public void move(String key) {
		switch(key){
		case "w" : move_type =1; break;
		case "s" : move_type =2; break;
		case "a" : move_type =3; break;
		case "d" : move_type =4; break;
		default : move_type =5;
		}
	}
	public void attack(String key) {
		if(key=="spacebar") {
			isAttack = true;
		}
		else isAttack = false;
	}
	public void sortItem(Item[] itemList) {
		Arrays.sort(itemList);
	}
	public Integer getMoveType() {
		return move_type;
	}
	public Boolean getIsAttack() {
		return isAttack;
	}
}