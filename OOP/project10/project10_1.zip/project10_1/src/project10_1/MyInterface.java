package project10_1;

public interface MyInterface {
	public abstract void move(String key);
	public abstract void attack(String key);
	public void sortItem(Item[] itemList);
}
