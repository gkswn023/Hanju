import glfw
from OpenGL.GL import *
import numpy as np
from OpenGL.GLU import *

#hw1
move_x = 0
move_y = 0
panning_x = 0
panning_y = 0
but = 0
act = 0
target = [0,0,0]
azimuth = 45.0
elevation = -36.0
x = 0
y = 0
z = 0
dist = 50.0
u = None
v = None
w = None
#hw3
skeleton = None
set_bvh = False
frame_control = -1
motion_flag = False

class Joint:
    def __init__(self, name):
        self.name = name
        self.children = []
        self.parent = None
        self.channels = []
        self.frames = []
        self.stransmat = []

    def updateFrame(self, frame):
        xpos = 0.0
        ypos = 0.0
        zpos = 0.0

        xrot = 0.0
        yrot = 0.0
        zrot = 0.0

        rotmat = np.identity(4)
        transmat = np.identity(4)

        if frame >= 0 and frame < len(self.frames):
            for index, channel in enumerate(self.channels):
                if channel == 'Xposition' or channel == 'XPOSITION':
                    xpos = self.frames[frame][index]
                    transmat[0,3] = xpos
                elif channel == 'Yposition' or channel == 'YPOSITION':
                    ypos = self.frames[frame][index]
                    transmat[1,3] = ypos
                elif channel == 'Zposition' or channel == 'ZPOSITION':
                    zpos = self.frames[frame][index] 
                    transmat[2,3] = zpos
              
                if channel == 'Xrotation' or channel == 'XROTATION':
                    xrot = self.frames[frame][index]
                    cos_theta = np.cos(np.radians(xrot))
                    sin_theta = np.sin(np.radians(xrot))
                    R = np.array([[1.,     0.,     0.,     0.],
                                  [0.,cos_theta,-sin_theta,0.],
                                  [0.,sin_theta, cos_theta,0.],
                                  [0.,     0.,     0.,     1.]])
                    rotmat = rotmat @ R
                elif channel == 'Yrotation' or channel == 'YROTATION':
                    yrot = self.frames[frame][index]
                    cos_theta = np.cos(np.radians(yrot))
                    sin_theta = np.sin(np.radians(yrot))
                    R = np.array([[ cos_theta,0.,sin_theta,0.],
                                  [0.,     1.,     0.,     0.],
                                  [-sin_theta,0.,cos_theta,0.],
                                  [0.,     0.,     0.,     1.]])
                    rotmat = rotmat @ R
                elif channel == 'Zrotation' or channel == 'ZROTATION':
                    zrot = self.frames[frame][index]
                    cos_theta = np.cos(np.radians(zrot))
                    sin_theta = np.sin(np.radians(zrot))
                    R = np.array([[cos_theta,-sin_theta,0.,0.],
                                  [sin_theta, cos_theta,0.,0.],
                                  [0.,     0.,     1.,     0.],
                                  [0.,     0.,     0.,     1.]])
                    rotmat = rotmat @ R

        self.rotmat = rotmat
        self.transmat = transmat

        if self.parent:
            self.localtoworld = self.parent.R @ self.stransmat
        else:
            self.localtoworld = self.stransmat @ self.transmat

        self.R = self.localtoworld @ self.rotmat

        self.worldpos = np.array([self.localtoworld[0,3],
                                  self.localtoworld[1,3],
                                  self.localtoworld[2,3], 
                                  self.localtoworld[3,3] ])

        for child in self.children:
           child.updateFrame(frame)

class Skeleton:
    def __init__(self, filename):   
        self.file = filename
        self.num_joint = 0
        self.joint_list = []

        self.Keyword('HIERARCHY')       
        items = self.Keyword('ROOT')
        self.root = Joint(items[1])
        self.joint_list.append(items[1])
        self.readJoint(self.root)
           
        self.Keyword('MOTION')
        items = self.Keyword('Frames:')
        self.frames = int(items[1])
        items = self.Keyword('Frame')
        self.frameTime = float(items[2])

        for i in range(self.frames):
            line = self.file.readline()
            items = line.split()
            data = [float(item) for item in items]
            data = self.ChannelData(self.root, data)

    def Position(self, joint):
        
        items = self.Keyword('OFFSET')
        joint.offset = [float(x) for x in items[1:]]
        
        joint.stransmat = np.identity(4)
        joint.stransmat[0,3] = joint.offset[0]
        joint.stransmat[1,3] = joint.offset[1]
        joint.stransmat[2,3] = joint.offset[2]            
                
    def readJoint(self, joint):
        
        self.Keyword('{')

        self.Position(joint)

        items = self.Keyword('CHANNELS')
        joint.channels = items[2:]

        while 1:
            items = self.Keyword('Select')
            
            if items[0] == 'JOINT':   
                child = Joint(items[1])
                self.joint_list.append(items[1])
                joint.children.append(child)
                child.parent = joint
                self.num_joint = self.num_joint + 1
                self.readJoint(child)
                
            elif items[0] == 'End':
                child = Joint(items[1])
                joint.children.append(child)
                child.parent = joint
                
                self.Keyword('{')
                self.Position(child)
                self.Keyword('}')
                
            elif items[0] == '}':
                break
                    
    def Keyword(self, keyword):
        
        line = self.file.readline()
        items = line.split()
                
        return items

    def ChannelData(self, joint, data):
        
        channels = len(joint.channels)
        joint.frames.append(data[0:channels])
        data = data[channels:]
        
        for child in joint.children:
            data = self.ChannelData(child, data)
        
        return data

def render():
    global x,y,z, target, azimuth, elevation, frame_control,skeleton, set_bvh

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, 1, 1, 1000)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    x = dist * -np.sin(np.radians(azimuth)) * np.cos(np.radians(elevation)) + target[0]
    y = dist * -np.sin(np.radians(elevation)) + target[1]
    z = -dist * np.cos(np.radians(azimuth)) * np.cos(np.radians(elevation)) + target[2] 
    # rotate "camera" position to see this 3D space better (we'll see details later)
    if np.cos(np.radians(elevation)) < 0 :
        myLookAt(np.array([x,y,z]),np.array([target[0],target[1],target[2]]), np.array([0,1,0]))
        gluLookAt(x,y,z, target[0],target[1],target[2], 0,-1,0)
    else :
        myLookAt(np.array([x,y,z]),np.array([target[0],target[1],target[2]]), np.array([0,1,0]))
        gluLookAt(x,y,z, target[0],target[1],target[2], 0,1,0)

    drawLine()
    if(set_bvh) :
        skeleton.root.updateFrame(frame_control)
        drawJoint(skeleton.root)

def drawJoint(joint):

    if joint.parent:
        head = [joint.parent.worldpos[0], joint.parent.worldpos[1], joint.parent.worldpos[2]]
        tail = [joint.worldpos[0], joint.worldpos[1], joint.worldpos[2]]
        glColor3ub(0, 0, 255);
        glBegin(GL_LINES)
        glVertex3f(head[0], head[1], head[2])
        glVertex3f(tail[0], tail[1], tail[2])
        glEnd();

    for child in joint.children:
        drawJoint(child)

def myLookAt(eye, at, up):
    global w,u,v
    w = (eye-at)/(np.sqrt(np.dot(eye-at,eye-at)))
    u = np.cross(up,w)/(np.sqrt(np.dot(np.cross(up,w),np.cross(up,w))))
    v = np.cross(w,u)

def drop_callback(window, paths):
    global skeleton, set_bvh, frame_control, motion_flag

    bvh_file = open(" ".join(paths), 'r')
    skeleton = Skeleton(bvh_file)
    frame_control = -1
    motion_flag = False
    set_bvh = True
    print("File name : " + str(paths))
    print("Number of frames : " + str(skeleton.frames))
    print("FPS (which is 1/FrameTime) : " + str(1 / skeleton.frameTime))
    print("Number of joints (including root) : " + str(skeleton.num_joint + 1))
    print("List of all joint names : " + str(skeleton.joint_list))

def cursor_callback(window, xpos, ypos):
    global move_x, move_y, panning_x, panning_y
    global but, act
    global azimuth, elevation
    global target
    global w,u,v,x,y,z
    if but==glfw.MOUSE_BUTTON_LEFT:
        if act == glfw.PRESS:
            if np.cos(np.radians(elevation)) >= 0 :
                if move_x < xpos:
                    a = -1
                elif move_x == xpos:
                    a = 0
                else :
                    a = 1
            else :
                if move_x < xpos:
                    a = 1
                elif move_x == xpos:
                    a = 0
                else :
                    a = -1
            if move_y < ypos:
                b = -1
            elif move_y == ypos:
                b = 0
            else :
                b = 1
            move_x = xpos
            move_y = ypos

            azimuth = (azimuth + a) % 360
            elevation = (elevation + b) % 360

    elif but == glfw.MOUSE_BUTTON_RIGHT:
        if act == glfw.PRESS:
            if np.cos(np.radians(elevation)) >= 0 :
                if panning_x < xpos:
                    a = -1
                elif panning_x == xpos:
                    a = 0
                else :
                    a = 1
                if panning_y < ypos:
                    b = -1
                elif panning_y == ypos:
                    b = 0
                else :
                    b = 1
            else :
                if panning_x < xpos:
                    a = 1
                elif panning_x == xpos:
                    a = 0
                else :
                    a = -1
                if panning_y < ypos:
                    b = 1
                elif panning_y == ypos:
                    b = 0
                else :
                    b = -1
            panning_x = xpos
            panning_y = ypos
            target[0] = target[0] + (u[0] * a*0.12) - (v[0] * b*0.12)
            target[1] = target[1] - (v[1] * b*0.12)
            target[2] = target[2] + (u[2] * a*0.12) - (v[2] * b*0.12)
            
def button_callback(window, button, action, mod):
    global move_x, move_y, panning_x, panning_y
    global but, act
    but = button
    act = action
    if button==glfw.MOUSE_BUTTON_LEFT:
        if action == glfw.PRESS:      
            move_x, move_y = glfw.get_cursor_pos(window)
    elif button==glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:      
            panning_x, panning_y = glfw.get_cursor_pos(window)
    

def scroll_callback(window, xoffset, yoffset):
    global dist
    dist = dist - yoffset*dist*0.08

def key_callback(window,key,scancode,action,mods):
    global motion_flag
    if action == glfw.PRESS or action == glfw.REPEAT:
        if key == glfw.KEY_SPACE:
            if motion_flag == True :
                motion_flag = False
            else :
                motion_flag = True

def drawLine():
    glBegin(GL_LINES)
    glColor3ub(0,255,0)
    glVertex3fv(np.array([-100,0,0]))
    glVertex3fv(np.array([100,0,0]))
    glColor3ub(255,0,0)
    glVertex3fv(np.array([0,0,100]))
    glVertex3fv(np.array([0,0,-100]))
    glColor3ub(255, 255, 255)
    for i in range(2,101, 2):
        glVertex3fv(np.array([-100,0.,i]))
        glVertex3fv(np.array([100,0.,i]))
        glVertex3fv(np.array([-100,0.,-i]))
        glVertex3fv(np.array([100,0.,-i]))
    glColor3ub(255, 255, 255)
    for i in range(2,101, 2):
        glVertex3fv(np.array([i,0.,-100]))
        glVertex3fv(np.array([i,0.,100]))
        glVertex3fv(np.array([-i,0.,-100]))
        glVertex3fv(np.array([-i,0.,100]))
    glEnd()

def main():
    global frame_control, skeleton, motion_flag
    # Initialize the library
    if not glfw.init():
        return
    # Create a windowed mode window and its OpenGL context
    window = glfw.create_window(1080, 1080, "2014005032-class3", None, None)
    if not window:
        glfw.terminate()
        return
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.set_key_callback(window, key_callback)
    glfw.set_drop_callback(window, drop_callback)

    # Make the window's context current
    glfw.make_context_current(window)

    glfw.swap_interval(1)
    # Loop until the user closes the window
    while not glfw.window_should_close(window):
        # Poll for and process events
        glfw.poll_events()
        if motion_flag == True :
            frame_control = frame_control + 1
            if frame_control == skeleton.frames :
                frame_control = 0
        # Render here, e.g. using pyOpenGL
        render()
        # Swap front and back buffers
        glfw.swap_buffers(window)

    glfw.terminate()
if __name__ == "__main__":
    main()
