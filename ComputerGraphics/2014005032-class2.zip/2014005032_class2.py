import glfw
from OpenGL.GL import *
import numpy as np
from OpenGL.GLU import *

#hw1
move_x = 0
move_y = 0
panning_x = 0
panning_y = 0
but = 0
act = 0
target = [0,0,0]
azimuth = 45.0
elevation = -36.0
x = 0
y = 0
z = 0
dist = 50.0
u = None
v = None
w = None
#hw2
mode = True
v1 = None
v2 = None
set_OBJ = False
flag = True
face_pos = []

def render():
    global x,y,z, target, azimuth, elevation, face_pos, set_OBJ, mode

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)

    if mode :
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
    else :
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, 1, 1, 100)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    x = dist * -np.sin(np.radians(azimuth)) * np.cos(np.radians(elevation)) + target[0]
    y = dist * -np.sin(np.radians(elevation)) + target[1]
    z = -dist * np.cos(np.radians(azimuth)) * np.cos(np.radians(elevation)) + target[2] 
    # rotate "camera" position to see this 3D space better (we'll see details later)
    if np.cos(np.radians(elevation)) < 0 :
        myLookAt(np.array([x,y,z]),np.array([target[0],target[1],target[2]]), np.array([0,1,0]))
        gluLookAt(x,y,z, target[0],target[1],target[2], 0,-1,0)
    else :
        myLookAt(np.array([x,y,z]),np.array([target[0],target[1],target[2]]), np.array([0,1,0]))
        gluLookAt(x,y,z, target[0],target[1],target[2], 0,1,0)
    drawLine()

    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1) #multiple light sources

    glPushMatrix()

    lightPos0=(5.,0.,0.,1.)
    lightPos1=(3.,4.,5.,1.)
    glLightfv(GL_LIGHT0,GL_POSITION,lightPos0)
    glLightfv(GL_LIGHT1,GL_POSITION,lightPos1)

    glPopMatrix()

    diffuseLightColor0 = (.5,.5,.5,1.)
    specularLightColor0 = (.5,.5,.5,.1)
    ambientLightColor0 = (.1,.1,.1,.1)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLightColor0)
    glLightfv(GL_LIGHT0, GL_SPECULAR, specularLightColor0)
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor0)

    diffuseLightColor1 = (.5,.5,.5,1.)
    specularLightColor1 = (.1,.1,.1,.1)
    ambientLightColor1 = (.1,.1,.1,.1)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLightColor1)
    glLightfv(GL_LIGHT0, GL_SPECULAR, specularLightColor1)
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor1)

    objectColor = (1.,1.,1.,1.)
    specularObjectColor = (1.,1.,1.,1.)
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, objectColor)
    glMaterialfv(GL_FRONT, GL_SHININESS, 10)
    glMaterialfv(GL_FRONT, GL_SPECULAR, specularObjectColor)

    glPushMatrix()

    glColor3ub(0, 0, 255)

    if(set_OBJ) :
        drawCube()

    glPopMatrix()

    glDisable(GL_LIGHTING)

def myLookAt(eye, at, up):
    global w,u,v
    w = (eye-at)/(np.sqrt(np.dot(eye-at,eye-at)))
    u = np.cross(up,w)/(np.sqrt(np.dot(np.cross(up,w),np.cross(up,w))))
    v = np.cross(w,u)

def drop_callback(window, paths):
    global v1, v2, set_OBJ, mode, face_pos

    mode = True
    nof_3 = 0
    nof_4 = 0
    nof_m4 = 0
    cnt = 0

    obj_file = open(" ".join(paths), 'r')
    obj_v = []
    obj_vn = []
    varr1 = []
    tmp_varr = []
    faces: [[[int, int], [int, int], [int, int]]] = []

    for i in obj_file :
        if i[:2] == "v ":
            j = i.split()
            obj_v.append(j[1:])
        elif i[:2] == "vn":
            j = i.split()
            obj_vn.append(j[1:])
        elif i[:2] == "f ":
            face = []
            j = i.split()
            tmp = np.array(j[1:])
            face_num = np.size(tmp)

            if face_num == 3:
                nof_3 += 1
            elif face_num == 4:
                nof_4 += 1
            else:
                nof_m4 += 1

            for k1 in j[1:4] :
                k2 = k1.split('/')

                k2[0] = int(k2[0])
                k2[2] = int(k2[2])

                varr1.append(obj_vn[k2[2]-1])
                varr1.append(obj_v[k2[0]-1])
                face.append([k2[0]-1, k2[2]-1])
            faces.append(face)

    v1 = np.array(varr1, 'float32')

    varr2 = np.zeros(shape=[len(faces) * 2 * 3, 3], dtype='float32')

    near = [set() for _ in range(len(obj_v))]

    for index, face in enumerate(faces):
        near[face[0][0]].add(index)
        near[face[1][0]].add(index)
        near[face[2][0]].add(index)

    normals = []
    for fs in near:
        normal = np.zeros(3, dtype='float32')
        for fi in fs:
            normal += v1[fi * 6]
        normal = normal / np.sqrt(np.dot(normal,normal))
        normals.append(normal)

    normals = np.array(normals, dtype='float32')

    for index, face in enumerate(faces):
        for i in range(3):
            varr2[index * 6 + i * 2] = normals[face[i][0]]
            varr2[index * 6 + i * 2 + 1] = obj_v[face[i][0]]

    v2 = np.array(varr2, 'float32')

    set_OBJ = True

    nof_total = nof_3 + nof_4 + nof_m4 

    print("File name : " + str(paths))
    print("Total number of faces : " + str(nof_total))
    print("Number of faces with 3 vertices : " + str(nof_3))
    print("Number of faces with 4 vertices : " + str(nof_4))
    print("Number of faces with more than 4 vertices : " + str(nof_m4))

def cursor_callback(window, xpos, ypos):
    global move_x, move_y, panning_x, panning_y
    global but, act
    global azimuth, elevation
    global target
    global w,u,v,x,y,z
    if but==glfw.MOUSE_BUTTON_LEFT:
        if act == glfw.PRESS:
            if np.cos(np.radians(elevation)) >= 0 :
                if move_x < xpos:
                    a = -1
                elif move_x == xpos:
                    a = 0
                else :
                    a = 1
            else :
                if move_x < xpos:
                    a = 1
                elif move_x == xpos:
                    a = 0
                else :
                    a = -1
            if move_y < ypos:
                b = -1
            elif move_y == ypos:
                b = 0
            else :
                b = 1
            move_x = xpos
            move_y = ypos

            azimuth = (azimuth + a) % 360
            elevation = (elevation + b) % 360

    elif but == glfw.MOUSE_BUTTON_RIGHT:
        if act == glfw.PRESS:
            if np.cos(np.radians(elevation)) >= 0 :
                if panning_x < xpos:
                    a = -1
                elif panning_x == xpos:
                    a = 0
                else :
                    a = 1
                if panning_y < ypos:
                    b = -1
                elif panning_y == ypos:
                    b = 0
                else :
                    b = 1
            else :
                if panning_x < xpos:
                    a = 1
                elif panning_x == xpos:
                    a = 0
                else :
                    a = -1
                if panning_y < ypos:
                    b = 1
                elif panning_y == ypos:
                    b = 0
                else :
                    b = -1
            panning_x = xpos
            panning_y = ypos
            target[0] = target[0] + (u[0] * a*0.12) - (v[0] * b*0.12)
            target[1] = target[1] - (v[1] * b*0.12)
            target[2] = target[2] + (u[2] * a*0.12) - (v[2] * b*0.12)
            
def button_callback(window, button, action, mod):
    global move_x, move_y, panning_x, panning_y
    global but, act
    but = button
    act = action
    if button==glfw.MOUSE_BUTTON_LEFT:
        if action == glfw.PRESS:      
            move_x, move_y = glfw.get_cursor_pos(window)
    elif button==glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:      
            panning_x, panning_y = glfw.get_cursor_pos(window)
    

def scroll_callback(window, xoffset, yoffset):
    global dist
    dist = dist - yoffset*dist*0.08

def key_callback(window,key,scancode,action,mods):
    global mode,flag
    if action == glfw.PRESS or action == glfw.REPEAT:
        if key == glfw.KEY_Z:
            mode = not mode
        elif key == glfw.KEY_S:
            flag = not flag

def drawCube():
    global v1, v2, flag
    if flag :
        varr = v1
    else :
        varr = v2
    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    glNormalPointer(GL_FLOAT,6*varr.itemsize,varr)
    glVertexPointer(3,GL_FLOAT,6*varr.itemsize,ctypes.c_void_p(varr.ctypes.data+3*varr.itemsize))
    glDrawArrays(GL_TRIANGLES,0,int(varr.size/6))     

def drawLine():
    glBegin(GL_LINES)
    glColor3ub(0,255,0)
    glVertex3fv(np.array([-8,0,0]))
    glVertex3fv(np.array([8,0,0]))
    glColor3ub(255,0,0)
    glVertex3fv(np.array([0,0,8]))
    glVertex3fv(np.array([0,0,-8]))
    glColor3ub(0,0,255)
    glVertex3fv(np.array([0,8,0]))
    glVertex3fv(np.array([0,0,0]))
    glColor3ub(255, 255, 255)
    for i in range(1,9):
        glVertex3fv(np.array([-8,0.,i]))
        glVertex3fv(np.array([8,0.,i]))
        glVertex3fv(np.array([-8,0.,-i]))
        glVertex3fv(np.array([8,0.,-i]))
    glColor3ub(255, 255, 255)
    for i in range(1,9):
        glVertex3fv(np.array([i,0.,-8]))
        glVertex3fv(np.array([i,0.,8]))
        glVertex3fv(np.array([-i,0.,-8]))
        glVertex3fv(np.array([-i,0.,8]))
    glEnd()

def main():
    # Initialize the library
    if not glfw.init():
        return
    # Create a windowed mode window and its OpenGL context
    window = glfw.create_window(1080, 1080, "2014005032-class2", None, None)
    if not window:
        glfw.terminate()
        return
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.set_key_callback(window, key_callback)
    glfw.set_drop_callback(window, drop_callback)

    # Make the window's context current
    glfw.make_context_current(window)

    glfw.swap_interval(1)
    # Loop until the user closes the window
    while not glfw.window_should_close(window):
        # Poll for and process events
        glfw.poll_events()
        # Render here, e.g. using pyOpenGL
        render()
        # Swap front and back buffers
        glfw.swap_buffers(window)

    glfw.terminate()
if __name__ == "__main__":
    main()