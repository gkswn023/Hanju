import glfw
from OpenGL.GL import *
import numpy as np
from OpenGL.GLU import *

move_x = 0
move_y = 0
panning_x = 0
panning_y = 0
but = 0
act = 0
target = [0,0,0]
azimuth = 45.0
elevation = -36.0
x = 0
y = 0
z = 0
dist = 50.0
u = None
v = None
w = None
body = np.array([2, 0.5, 1])
arm = np.array([1.3,.2,.2])
leg1 = np.array([0.7, 0.2, 0.2])
body_ang = 0
body_turn = 1
leg_ang = 10
leg_up = 1
cnt = 0
arm_up = 1
position = -8
z_pos = 1

def render():
    global x,y,z, target, azimuth, elevation
    global body_ang,body_turn, leg_ang, leg_up, cnt, arm_up, position, z_pos
    if(position <= -8):
        position = 8
        z_pos *= -1
    if((0.1*cnt + 15) % 30 == 0) :
        if body_turn == 1 :
            body_turn = 0
        elif body_turn == 0 :
            body_turn = 1
    if body_turn == 1:
        body_ang += 0.2
    elif body_turn == 0:
        body_ang -= 0.2

    if 1.5*cnt % 360 == 0 :
        if arm_up == 1 :
            arm_up = 0
        elif arm_up == 0 :
            arm_up =1
    if(leg_ang >= 30) :
        leg_up = 0
    elif leg_ang <= -30 :
        leg_up = 1
    if leg_up == 0 :
        leg_ang -= .3
    elif leg_up == 1 :
        leg_ang += .3
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

    glLoadIdentity()
    gluPerspective(45, 1, 1, 100)

    x = dist * -np.sin(np.radians(azimuth)) * np.cos(np.radians(elevation)) + target[0]
    y = dist * -np.sin(np.radians(elevation)) + target[1]
    z = -dist * np.cos(np.radians(azimuth)) * np.cos(np.radians(elevation)) + target[2] 
    # rotate "camera" position to see this 3D space better (we'll see details later)
    if np.cos(np.radians(elevation)) < 0 :
        myLookAt(np.array([x,y,z]),np.array([target[0],target[1],target[2]]), np.array([0,1,0]))
        gluLookAt(x,y,z, target[0],target[1],target[2], 0,-1,0)
    else :
        myLookAt(np.array([x,y,z]),np.array([target[0],target[1],target[2]]), np.array([0,1,0]))
        gluLookAt(x,y,z, target[0],target[1],target[2], 0,1,0)
    drawUnitCube(255, 255, 255)
    drawLine()
    glTranslatef(position,2,z_pos*5)
    glRotatef(body_ang,1,0,0)
    #몸통
    glPushMatrix()
    glScalef(body[0],body[1],body[2])
    drawCube(0,0,255)
    glPopMatrix()
    #머리
    glPushMatrix()
    glTranslatef(-(body[0]+0.5), 0 ,0)
    drawSphere()
    glPopMatrix()
    #왼팔
    glPushMatrix()
    glTranslatef(-body[0], 0, body[2] + arm[2])
    if arm_up == 1:
        glRotatef(1.5*cnt % 360, 0,0,1)
    glTranslatef(-0.7*arm[0], 0, 0)
    glScalef(arm[0],arm[1],arm[2])
    drawCube(255,235,203)
    glPopMatrix()
    #오른팔
    glPushMatrix()
    glTranslatef(-body[0], 0,-(body[2] + arm[2]))
    if arm_up == 0:
        glRotatef(1.5*cnt % 360, 0,0,1)
    glTranslatef(-0.7*arm[0], 0, 0)
    glScalef(arm[0],arm[1],arm[2])
    drawCube(255,235,203)
    glPopMatrix()
    #왼쪽 다리 (허벅지, 무릎아래)
    glPushMatrix()
    glTranslatef(body[0], 0,- (body[2] + leg1[2]))
    glRotatef(leg_ang, 0,0,1)
    glTranslatef(0.5*leg1[0], 0, 0)
    glPushMatrix()
    glScalef(leg1[0],leg1[1],leg1[2])
    drawCube(255,235,203)
    glPopMatrix()
    glTranslatef(leg1[0], 0, 0)
    if leg_ang >= 0 :
        glRotatef(2*leg_ang, 0, 0, 1)
    glTranslatef(leg1[0],0,0)
    glScalef(leg1[0], leg1[1], leg1[2])
    drawCube(255,235,203)
    glPopMatrix()
    #오른쪽 다리( 허벅지, 무릎아래)
    glPushMatrix()
    glTranslatef(body[0], 0, (body[2] + leg1[2]))
    glRotatef(-leg_ang, 0,0,1)
    glTranslatef(0.5*leg1[0], 0, 0)
    glPushMatrix()
    glScalef(leg1[0],leg1[1],leg1[2])
    drawCube(255,235,203)
    glPopMatrix()
    glTranslatef(leg1[0], 0, 0)
    if leg_ang <= 0 :
        glRotatef(-2*leg_ang, 0, 0, 1)
    glTranslatef(leg1[0],0,0)
    glScalef(leg1[0], leg1[1], leg1[2])
    drawCube(255,235,203)
    glPopMatrix()

def drawSphere (numLats=12, numLongs=12):
    glColor3ub(255,235,203)
    for i in range(0, numLats + 1):
        lat0 = np.pi * (-0.5 + float(float(i-1) / float(numLats)))
        z0 = np.sin(lat0)
        zr0 = np.cos(lat0)

        lat1 = np.pi * (-0.5 + float(float(i) / float(numLats)))
        z1 = np.sin(lat1)
        zr1 = np.cos(lat1)

        glBegin(GL_QUAD_STRIP)

        for j in range(0, numLongs + 1):
            lng = 2 * np.pi * float(float(j-1) / float(numLongs))
            x = np.cos(lng)
            y = np.sin(lng)
            glVertex3f(x * zr0, y * zr0, z0)
            glVertex3f(x * zr1, y * zr1, z1)

        glEnd()

def drawCube(R,G,B):

   glColor3ub(R,G,B)
   glBegin(GL_QUADS)
   glVertex3f(1.0, 1.0, -1.0)
   glVertex3f(-1.0, 1.0, -1.0)
   glVertex3f(-1.0, 1.0, 1.0)
   glVertex3f(1.0, 1.0, 1.0)

   glVertex3f(1.0, -1.0, 1.0)
   glVertex3f(-1.0, -1.0, 1.0)
   glVertex3f(-1.0, -1.0, -1.0)
   glVertex3f(1.0, -1.0, -1.0)

   glVertex3f(1.0, 1.0, 1.0)
   glVertex3f(-1.0, 1.0, 1.0)
   glVertex3f(-1.0, -1.0, 1.0)
   glVertex3f(1.0, -1.0, 1.0)

   glVertex3f(1.0, -1.0, -1.0)
   glVertex3f(-1.0, -1.0, -1.0)
   glVertex3f(-1.0, 1.0, -1.0)
   glVertex3f(1.0, 1.0, -1.0)

   glVertex3f(-1.0, 1.0, 1.0)
   glVertex3f(-1.0, 1.0, -1.0)
   glVertex3f(-1.0, -1.0, -1.0)
   glVertex3f(-1.0, -1.0, 1.0)

   glVertex3f(1.0, 1.0, -1.0)
   glVertex3f(1.0, 1.0, 1.0)
   glVertex3f(1.0, -1.0, 1.0)
   glVertex3f(1.0, -1.0, -1.0)
 
   glEnd()
        
def myLookAt(eye, at, up):
    global w,u,v
    w = (eye-at)/(np.sqrt(np.dot(eye-at,eye-at)))
    u = np.cross(up,w)/(np.sqrt(np.dot(np.cross(up,w),np.cross(up,w))))
    v = np.cross(w,u)

def cursor_callback(window, xpos, ypos):
    global move_x, move_y, panning_x, panning_y
    global but, act
    global azimuth, elevation
    global target
    global w,u,v,x,y,z
    if but==glfw.MOUSE_BUTTON_LEFT:
        if act == glfw.PRESS:
            if np.cos(np.radians(elevation)) >= 0 :
                if move_x < xpos:
                    a = -1
                elif move_x == xpos:
                    a = 0
                else :
                    a = 1
            else :
                if move_x < xpos:
                    a = 1
                elif move_x == xpos:
                    a = 0
                else :
                    a = -1
            if move_y < ypos:
                b = -1
            elif move_y == ypos:
                b = 0
            else :
                b = 1
            move_x = xpos
            move_y = ypos

            azimuth = (azimuth + a) % 360
            elevation = (elevation + b) % 360

    elif but == glfw.MOUSE_BUTTON_RIGHT:
        if act == glfw.PRESS:
            if np.cos(np.radians(elevation)) >= 0 :
                if panning_x < xpos:
                    a = -1
                elif panning_x == xpos:
                    a = 0
                else :
                    a = 1
                if panning_y < ypos:
                    b = -1
                elif panning_y == ypos:
                    b = 0
                else :
                    b = 1
            else :
                if panning_x < xpos:
                    a = 1
                elif panning_x == xpos:
                    a = 0
                else :
                    a = -1
                if panning_y < ypos:
                    b = 1
                elif panning_y == ypos:
                    b = 0
                else :
                    b = -1
            panning_x = xpos
            panning_y = ypos
            target[0] = target[0] + (u[0] * a*0.12) - (v[0] * b*0.12)
            target[1] = target[1] - (v[1] * b*0.12)
            target[2] = target[2] + (u[2] * a*0.12) - (v[2] * b*0.12)
            
def button_callback(window, button, action, mod):
    global move_x, move_y, panning_x, panning_y
    global but, act
    but = button
    act = action
    if button==glfw.MOUSE_BUTTON_LEFT:
        if action == glfw.PRESS:      
            move_x, move_y = glfw.get_cursor_pos(window)
    elif button==glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:      
            panning_x, panning_y = glfw.get_cursor_pos(window)
    

def scroll_callback(window, xoffset, yoffset):
    global dist
    dist = dist - yoffset*dist*0.08

def drawUnitCube(R,G,B):
    glColor3ub(R,G,B)
    glBegin(GL_QUADS)
    glVertex3f( 1, 1,-1)
    glVertex3f(-1, 1,-1)
    glVertex3f(-1, 1, 1)
    glVertex3f( 1, 1, 1) 
                             
    glVertex3f( 1,-1, 1)
    glVertex3f(-1,-1, 1)
    glVertex3f(-1,-1,-1)
    glVertex3f( 1,-1,-1) 
                             
    glVertex3f( 1, 1, 1)
    glVertex3f(-1, 1, 1)
    glVertex3f(-1,-1, 1)
    glVertex3f( 1,-1, 1)
                             
    glVertex3f( 1,-1,-1)
    glVertex3f(-1,-1,-1)
    glVertex3f(-1, 1,-1)
    glVertex3f( 1, 1,-1)
 
    glVertex3f(-1, 1, 1) 
    glVertex3f(-1, 1,-1)
    glVertex3f(-1,-1,-1) 
    glVertex3f(-1,-1, 1) 
                             
    glVertex3f( 1, 1,-1) 
    glVertex3f( 1, 1, 1)
    glVertex3f( 1,-1, 1)
    glVertex3f( 1,-1,-1)
    glEnd()

def drawLine():
    glBegin(GL_LINES)
    glColor3ub(0,255,0)
    glVertex3fv(np.array([-8,0,0]))
    glVertex3fv(np.array([8,0,0]))
    glColor3ub(255,0,0)
    glVertex3fv(np.array([0,0,8]))
    glVertex3fv(np.array([0,0,-8]))
    glColor3ub(0,0,255)
    glVertex3fv(np.array([0,8,0]))
    glVertex3fv(np.array([0,0,0]))
    glColor3ub(255, 255, 255)
    for i in range(1,9):
        glVertex3fv(np.array([-8,0.,i]))
        glVertex3fv(np.array([8,0.,i]))
        glVertex3fv(np.array([-8,0.,-i]))
        glVertex3fv(np.array([8,0.,-i]))
    glColor3ub(255, 255, 255)
    for i in range(1,9):
        glVertex3fv(np.array([i,0.,-8]))
        glVertex3fv(np.array([i,0.,8]))
        glVertex3fv(np.array([-i,0.,-8]))
        glVertex3fv(np.array([-i,0.,8]))
    glEnd()

def main():
    global cnt, position
    # Initialize the library
    if not glfw.init():
        return
    # Create a windowed mode window and its OpenGL context
    window = glfw.create_window(1080, 1080, "2014005032-hw1", None, None)
    if not window:
        glfw.terminate()
        return
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)

    # Make the window's context current
    glfw.make_context_current(window)

    # Loop until the user closes the window
    while not glfw.window_should_close(window):
        # Poll for and process events
        glfw.poll_events()
        # Render here, e.g. using pyOpenGL
        render()
        cnt += 1
        position -= 0.01
        # Swap front and back buffers
        glfw.swap_buffers(window)

    glfw.terminate()
if __name__ == "__main__":
    main()

